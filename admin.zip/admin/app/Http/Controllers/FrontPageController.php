<?php

namespace App\Http\Controllers;
use App\Models\Posts;

use Illuminate\Http\Request;

class FrontPageController extends Controller
{
    public function showFrontendPage()
    {
        $posts= Posts::where('approved', '1')->get();
        return view('front.home',compact('posts'));
    }

}
