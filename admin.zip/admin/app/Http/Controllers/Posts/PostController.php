<?php

namespace App\Http\Controllers\Posts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Posts;
use Illuminate\Support\Facades\Validator;


class PostController extends Controller
{
    public function index()
    {
        $posts = Posts::paginate(15);
        return view('posts.index',compact('posts'));
    }

    public function create()
    {
        return view('posts.create');
    }

    public function store(Request $request)
    {

        $validatedData = $request->validate([
            'name' => 'required',
            'content' => 'required',
        ]);
        $data = $request->all();

        $posts = Posts::create($data);
        $this->flashMessage('check', 'posts successfully added!', 'success');

        return redirect()->route('posts.create');
    }

    public function edit($id)
    {
        $posts = Posts::find($id);

        if(!$posts){
            $this->flashMessage('warning', 'Posts not found!', 'danger');
            return redirect()->route('posts');
        }

        return view('posts.edit',compact('posts'));
    }

    public function update(Request $request, $id)
    {
        $posts = Posts::find($id);

        if(!$posts){
            $this->flashMessage('warning', 'Posts not found!', 'danger');
            return redirect()->route('posts');
        }

        $validatedData = $request->validate([
            'name' => 'required',
            'content' => 'required',
            'approved' => 'nullable|boolean',

        ]);
        if(empty($request['approved']))
        {
            $request['approved']=0;
        }
        $data = $request->all();

        $posts->update($data);

        $this->flashMessage('check', 'posts updated successfully!', 'success');

        return redirect()->route('posts');


    }

    public function delete($id)
    {
        $posts = Posts::find($id);

        if(!$posts){
            $this->flashMessage('warning', 'Post not found!', 'danger');
            return redirect()->route('posts');
        }

        $posts->delete();

        $this->flashMessage('check', 'Post successfully deleted!', 'success');

        return redirect()->route('posts');
    }

}
