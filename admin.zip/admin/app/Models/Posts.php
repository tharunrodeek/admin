<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Posts extends Model
{
    use HasFactory;

    protected $table = 'posts';

    // Specify which attributes are mass assignable
    protected $fillable = [
        'name',
        'content',
        'status',
        'approved'
        // Add other fillable attributes here
    ];

}
