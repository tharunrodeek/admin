<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Posts</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
<header>
    <h1>Blog Posts</h1>
    <nav>
        <a href="{{ url('/') }}">Home</a> |
        <a href="{{ url('/posts') }}">All Posts</a>
    </nav>
</header>

<main>
    <ul>
        @foreach($posts as $post)
            <li>
                <a href="#">{{ $post->name }}</a>
                <p>{{ Str::limit($post->content, 100) }}</p> <!-- Show an excerpt of the post -->
            </li>
        @endforeach
    </ul>
</main>

<footer>
    <p>&copy; {{ date('Y') }} My Blog. All rights reserved.</p>
</footer>
</body>
</html>
