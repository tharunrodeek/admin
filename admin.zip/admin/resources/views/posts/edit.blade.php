@extends('layouts.AdminLTE.index')

@section('icon_page', 'plus')

@section('title', 'Add New Post')

@section('menu_pagina')

    <li role="presentation">
        <a href="{{ route('posts') }}" class="link_menu_page">
            <i class="fa fa-user"></i> Posts
        </a>
    </li>

@endsection

@section('content')

    <div class="box box-primary">
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">

                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ route('posts.update',$posts->id) }}" method="post">
                        {{ csrf_field() }}
                        <input type="hidden" name="active" value="1">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                                    <label for="nome">Post Name</label>
                                    <input type="text" name="name" class="form-control" maxlength="30" minlength="4" placeholder="Enter Post Name"  value="{{$posts->name}}" autofocus>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group {{ $errors->has('content') ? 'has-error' : '' }}">
                                    <label for="nome">Post Content</label>
                                    <textarea name="content" class="form-control" maxlength="100" minlength="4" placeholder="Enter Post Content" >{{$posts->content}}</textarea>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                                    <label for="nome">Status</label>
                                    <select name="status" id="ddlStatus" class="form-control">
                                        @if($posts->status==true)
                                            <option value="1" selected>Active</option>
                                            <option value="0">Inactive</option>
                                        @elseif($posts->status==false)
                                            <option value="1">Active</option>
                                            <option value="0" selected>Inactive</option>
                                         @endif
                                    </select>

                                    @if($errors->has('status'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('status') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                                    <label for="nome">Approve Post</label>
                                    <input type="checkbox" id="approved" name="approved" value="1" {{ old('approved', $posts->approved) ? 'checked' : '' }}/>
                                </div>
                            </div>

                            <div class="col-lg-6"></div>
                            <div class="col-lg-6">
                                <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-fw fa-plus"></i> Save Post</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
