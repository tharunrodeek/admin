@extends('layouts.AdminLTE.index')

@section('icon_page', 'posts')

@section('title', 'Posts')

@section('menu_pagina')

    <li role="presentation">
        <a href="{{ route('user.create') }}" class="link_menu_page">
            <i class="fa fa-plus"></i> Add New Posts
        </a>
    </li>
@endsection

@section('content')

    <div class="box box-primary">
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table id="tabelapadrao" class="table table-condensed table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>Post Name</th>
                                <th>Content</th>
                                <th class="text-center">Post Status</th>
                                <th class="text-center">Post Approved</th>
                                <th class="text-center">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($posts as $post)
                                <tr>
                                    <td>{{$post->name}}</td>
                                    <td>{{$post->content}}</td>
                                    <td>
                                        @if($post->status == true)
                                            <span class="label label-success">Active</span>
                                        @else
                                            <span class="label label-danger">Inactive</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($post->approved == true)
                                            <span class="label label-success">Post Approved</span>
                                        @else
                                            <span class="label label-danger">Not Approved</span>
                                        @endif
                                    </td>
                                    <td>
                                        <a class="btn btn-warning  btn-xs" href="{{ route('posts.edit', $post->id) }}" title="Edit {{ $post->name }}"><i class="fa fa-pencil"></i></a>
                                        <a class="btn btn-danger  btn-xs" href="#" title="Delete {{ $post->name}}" data-toggle="modal" data-target="#modal-delete-{{ $post->id }}"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>

                                <div class="modal fade" id="modal-delete-{{ $post->id }}">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                                <h4 class="modal-title"><i class="fa fa-warning"></i> Caution!!</h4>
                                            </div>
                                            <div class="modal-body">
                                                <p>Do you really want to delete?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                                                <a href="{{ route('posts.delete', $post->id) }}"><button type="button" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            @endforeach
                            </tbody>

                        </table>
                    </div>
                </div>
                <div class="col-md-12 text-center">

                </div>
            </div>
        </div>
    </div>

@endsection
