<?php $__env->startSection('icon_page', 'pencil'); ?>

<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('user')); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Users
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <?php if($user->id != 1): ?>     
        <div class="box box-primary">
    		<div class="box-body">
    			<div class="row">
    				<div class="col-md-12">	
    					 <form action="<?php echo e(route('user.update',$user->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="put">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                        <label for="nome">Name</label>
                                        <input type="text" name="name" class="form-control" maxlength="30" minlength="4" placeholder="Name" required="" autofocus value="<?php echo e($user->name); ?>">
                                        <?php if($errors->has('name')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                        <label for="nome">E-mail</label>
                                        <input type="email" name="email" class="form-control" placeholder="E-mail" required="" value="<?php echo e($user->email); ?>">
                                        <?php if($errors->has('email')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group <?php echo e($errors->has('roles') ? 'has-error' : ''); ?>">
                                        <label for="nome">Permission Group</label>
                                        <select name="roles[]" class="form-control select2" multiple="multiple" data-placeholder="Permission Group">
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($role->id != 1): ?>
                                                    <?php if(in_array($role->id, $roles_ids)): ?>
                                                        <option value="<?php echo e($role->id); ?>" selected="true"> <?php echo e($role->name); ?> </option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($role->id); ?>"> <?php echo e($role->name); ?> </option>
                                                    <?php endif; ?>                                             
                                                <?php endif; ?>                                             
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('roles')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('roles')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">                                    
                                        <label>
                                            <input type="hidden" name="active" value="0">
                                            <input type="checkbox" name="active" value="1" class="minimal" id="icheck" 
                                            <?php if($user->active == true): ?>
                                                checked
                                            <?php endif; ?>
                                            >
                                            Active
                                        </label>
                                    </div>
                                </div> 
                                <div class="col-lg-6">
                                   <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-fw fa-save"></i> Save</button>
                                </div>
                            </div>
                        </form>
    				</div>
    			</div>
    		</div>
    	</div>    
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_js'); ?>    

    <script> 
        $(function(){             
            $('.select2').select2({
                "language": {
                    "noResults": function(){
                        return "No records found.";
                    }
                }
            });
            
            $('#icheck').iCheck({
              checkboxClass: 'icheckbox_square-blue',
              radioClass: 'iradio_square-blue'
            });
        }); 

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/admin/resources/views/users/edit.blade.php ENDPATH**/ ?>