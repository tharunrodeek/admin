<?php $__env->startSection('icon_page', 'plus'); ?>

<?php $__env->startSection('title', 'Add New Post'); ?>

<?php $__env->startSection('menu_pagina'); ?>

    <li role="presentation">
        <a href="<?php echo e(route('posts')); ?>" class="link_menu_page">
            <i class="fa fa-user"></i> Posts
        </a>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="box box-primary">
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('posts.store')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="active" value="1">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="nome">Post Name</label>
                                    <input type="text" name="name" class="form-control" maxlength="30" minlength="4" placeholder="Enter Post Name"  value="<?php echo e(old('name')); ?>" autofocus>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="nome">Post Content</label>
                                    <textarea name="content" class="form-control" maxlength="100" minlength="4" placeholder="Enter Post Content"></textarea>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="nome">Status</label>
                                    <select name="status" id="ddlStatus" class="form-control">
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>

                                    <?php if($errors->has('status')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="nome">Approve Post</label>
                                    <input type="checkbox" id="approved" name="approved" value="1"/>
                                </div>
                            </div>

                            <div class="col-lg-6"></div>
                            <div class="col-lg-6">
                                <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-fw fa-plus"></i> Save Post</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/admin/resources/views/posts/create.blade.php ENDPATH**/ ?>