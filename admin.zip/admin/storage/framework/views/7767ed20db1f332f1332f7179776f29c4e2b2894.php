<?php $__env->startSection('icon_page', 'user'); ?>

<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('menu_pagina'); ?>

	<li role="presentation">
		<a href="<?php echo e(route('user.create')); ?>" class="link_menu_page">
			<i class="fa fa-plus"></i> Add User
		</a>
	</li>
	<li role="presentation">
		<a href="<?php echo e(route('role')); ?>" class="link_menu_page">
			<i class="fa fa-unlock-alt"></i> Permissions
		</a>
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="box box-primary">
		<div class="box-body">
			<div class="row">
				<div class="col-md-12">
					<div class="table-responsive">
						<table id="tabelapadrao" class="table table-condensed table-bordered table-hover">
							<thead>
								<tr>
									<th>Name</th>
									<th>E-mail</th>
									<th class="text-center">Status</th>
									<th class="text-center">Created</th>
									<th class="text-center">Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($user->id != 1): ?>
										<tr>
											<td>
												<?php if($user->isOnline()): ?>
						                            <a herf="#" title="OnLine"><span class="text-green"><i class="fa fa-fw fa-circle"></i></span></a>
												<?php else: ?>
													<a herf="#" title="OffLine"><span class="text-red"><i class="fa fa-fw fa-circle"></i></span></a>
						                        <?php endif; ?>
												<?php echo e($user->name); ?>

											</td>
											<td><?php echo e($user->email); ?></td>
											<td class="text-center">
												<?php if($user->active == true): ?>
													<span class="label label-success">Active</span>
												<?php else: ?>
													<span class="label label-danger">Inactive</span>
												<?php endif; ?>
											</td>
											<td class="text-center"><?php echo e($user->created_at->format('d/m/Y H:i')); ?></td>
											<td class="text-center">
												 <a class="btn btn-default  btn-xs" href="<?php echo e(route('user.show', $user->id)); ?>" title="See <?php echo e($user->name); ?>"><i class="fa fa-eye">   </i></a>
												 <a class="btn btn-primary  btn-xs" href="<?php echo e(route('user.edit.password', $user->id)); ?>" title="Change Password <?php echo e($user->name); ?>"><i class="fa fa-key"></i></a>
												 <a class="btn btn-warning  btn-xs" href="<?php echo e(route('user.edit', $user->id)); ?>" title="Edit <?php echo e($user->name); ?>"><i class="fa fa-pencil"></i></a>
												 <a class="btn btn-danger  btn-xs" href="#" title="Delete <?php echo e($user->name); ?>" data-toggle="modal" data-target="#modal-delete-<?php echo e($user->id); ?>"><i class="fa fa-trash"></i></a>
												 <?php if(Auth::user()->can('root-dev', '')): ?>
												 	<a class="btn btn-info  btn-xs" href="<?php echo e(route('impersonate', $user->id)); ?>" title="Impersonate user"><i class="fa fa-user"></i></a>
												 <?php endif; ?>
											</td>
										</tr>
										<div class="modal fade" id="modal-delete-<?php echo e($user->id); ?>">
											<div class="modal-dialog">
												<div class="modal-content">
													<div class="modal-header">
														<button type="button" class="close" data-dismiss="modal" aria-label="Close">
															<span aria-hidden="true">×</span>
														</button>
														<h4 class="modal-title"><i class="fa fa-warning"></i> Caution!!</h4>
													</div>
													<div class="modal-body">
														<p>Do you really want to delete (<?php echo e($user->name); ?>) ?</p>
													</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
														<a href="<?php echo e(route('user.destroy', $user->id)); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button></a>
													</div>
												</div>
											</div>
										</div>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
							<tfoot>
								<tr>
									<th>Name</th>
									<th>E-mail</th>
									<th class="text-center">Status</th>
									<th class="text-center">Created</th>
									<th class="text-center">Actions</th>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>
				<div class="col-md-12 text-center">
					<?php echo e($users->links()); ?>

				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/admin/resources/views/users/index.blade.php ENDPATH**/ ?>