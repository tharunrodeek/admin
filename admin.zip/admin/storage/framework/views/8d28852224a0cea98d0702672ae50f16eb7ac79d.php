<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Posts</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<header>
    <h1>Blog Posts</h1>
    <nav>
        <a href="<?php echo e(url('/')); ?>">Home</a> |
        <a href="<?php echo e(url('/posts')); ?>">All Posts</a>
    </nav>
</header>

<main>
    <ul>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="#"><?php echo e($post->name); ?></a>
                <p><?php echo e(Str::limit($post->content, 100)); ?></p> <!-- Show an excerpt of the post -->
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</main>

<footer>
    <p>&copy; <?php echo e(date('Y')); ?> My Blog. All rights reserved.</p>
</footer>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/admin/resources/views/front/home.blade.php ENDPATH**/ ?>