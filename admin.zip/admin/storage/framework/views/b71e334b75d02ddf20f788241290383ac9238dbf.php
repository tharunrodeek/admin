<aside class="main-sidebar">
	<section class="sidebar">
		<ul class="sidebar-menu" data-widget="tree">
			<li class="header" style="color:#fff;"> MAIN MENU <i class="fa fa-level-down"></i></li>  
			<li class="
						<?php echo e(Request::segment(1) === null ? 'active' : null); ?>

						<?php echo e(Request::segment(1) === 'home' ? 'active' : null); ?>

					  ">
				<a href="<?php echo e(route('home')); ?>" title="Dashboard"><i class="fa fa-dashboard"></i> <span> Dashboard</span></a>
			</li>
			
			<?php if(Request::segment(1) === 'profile'): ?>

			<li class="<?php echo e(Request::segment(1) === 'profile' ? 'active' : null); ?>">
				<a href="<?php echo e(route('profile')); ?>" title="Profile"><i class="fa fa-user"></i> <span> PROFILE</span></a>
			</li>

			<?php endif; ?>
			<li class="treeview 
				<?php echo e(Request::segment(1) === 'config' ? 'active menu-open' : null); ?>

				<?php echo e(Request::segment(1) === 'user' ? 'active menu-open' : null); ?>

				<?php echo e(Request::segment(1) === 'role' ? 'active menu-open' : null); ?>

				">
				<a href="#">
					<i class="fa fa-gear"></i>
					<span>SETTINGS</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
				<ul class="treeview-menu">
					<?php if(Auth::user()->can('root-dev', '')): ?>
						<li class="<?php echo e(Request::segment(1) === 'config' && Request::segment(2) === null ? 'active' : null); ?>">
							<a href="<?php echo e(route('config')); ?>" title="App Config">
								<i class="fa fa-gear"></i> <span> Settings App</span>
							</a>
						</li>
					<?php endif; ?>					
					<li class="
						<?php echo e(Request::segment(1) === 'user' ? 'active' : null); ?>

						<?php echo e(Request::segment(1) === 'role' ? 'active' : null); ?>

						">
						<a href="<?php echo e(route('user')); ?>" title="Users">
							<i class="fa fa-user"></i> <span> Users</span>
						</a>
					</li>
				</ul>
			</li>      
		</ul>
	</section>
</aside><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/admin/resources/views/layouts/AdminLTE/_includes/_menu_lateral.blade.php ENDPATH**/ ?>