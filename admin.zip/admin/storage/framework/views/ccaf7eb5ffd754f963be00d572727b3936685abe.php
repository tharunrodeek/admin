<?php $__env->startSection('icon_page', 'posts'); ?>

<?php $__env->startSection('title', 'Posts'); ?>

<?php $__env->startSection('menu_pagina'); ?>

    <li role="presentation">
        <a href="<?php echo e(route('user.create')); ?>" class="link_menu_page">
            <i class="fa fa-plus"></i> Add New Posts
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="box box-primary">
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table id="tabelapadrao" class="table table-condensed table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>Post Name</th>
                                <th>Content</th>
                                <th class="text-center">Post Status</th>
                                <th class="text-center">Post Approved</th>
                                <th class="text-center">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($post->name); ?></td>
                                    <td><?php echo e($post->content); ?></td>
                                    <td>
                                        <?php if($post->status == true): ?>
                                            <span class="label label-success">Active</span>
                                        <?php else: ?>
                                            <span class="label label-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($post->approved == true): ?>
                                            <span class="label label-success">Post Approved</span>
                                        <?php else: ?>
                                            <span class="label label-danger">Not Approved</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="btn btn-warning  btn-xs" href="<?php echo e(route('posts.edit', $post->id)); ?>" title="Edit <?php echo e($post->name); ?>"><i class="fa fa-pencil"></i></a>
                                        <a class="btn btn-danger  btn-xs" href="#" title="Delete <?php echo e($post->name); ?>" data-toggle="modal" data-target="#modal-delete-<?php echo e($post->id); ?>"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>

                                <div class="modal fade" id="modal-delete-<?php echo e($post->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                                <h4 class="modal-title"><i class="fa fa-warning"></i> Caution!!</h4>
                                            </div>
                                            <div class="modal-body">
                                                <p>Do you really want to delete?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                                                <a href="<?php echo e(route('posts.delete', $post->id)); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
                <div class="col-md-12 text-center">

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/admin/resources/views/posts/index.blade.php ENDPATH**/ ?>