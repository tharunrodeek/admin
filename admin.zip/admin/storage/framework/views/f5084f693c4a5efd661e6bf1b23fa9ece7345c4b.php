<?php $__env->startSection('icon_page', 'gear'); ?>

<?php $__env->startSection('title', 'Application Settings'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
    
        <div class="col-md-12">
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#general" data-toggle="tab"><i class="fa fa-fw fa-gear"></i> General</a></li>
                    <li><a href="#permissiongroups" data-toggle="tab"><i class="fa fa-fw fa-group"></i> Permission groups</a></li>
                    <li><a href="#permissions" data-toggle="tab"><i class="fa fa-fw fa-unlock-alt"></i> Permissions</a></li>
                </ul>
                <div class="tab-content">
                    <div class="active tab-pane" id="general">

                        <div class="row">
                            <div class="col-md-12"> 
                                <form action="<?php echo e(route('config.update',$config->id)); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="put">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <h4><b><i class="fa fa-fw fa-arrow-right"></i> General information</b></h4>
                                            <hr/>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group <?php echo e($errors->has('app_name') ? 'has-error' : ''); ?>">
                                                <label for="nome">Application Name</label>
                                                <input type="text" name="app_name" class="form-control"  maxlength="30" placeholder="Application Name" value="<?php echo e($config->app_name); ?>" required>
                                                <?php if($errors->has('app_name')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('app_name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="form-group <?php echo e($errors->has('app_name_abv') ? 'has-error' : ''); ?>">
                                                <label for="nome">Short Name</label>
                                                <input type="text" name="app_name_abv" class="form-control"  maxlength="5" value="<?php echo e($config->app_name_abv); ?>" required>
                                                <?php if($errors->has('app_name_abv')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('app_name_abv')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-7">
                                            <div class="form-group <?php echo e($errors->has('app_slogan') ? 'has-error' : ''); ?>">
                                                <label for="nome">App Slogan</label>
                                                <input type="text" name="app_slogan" class="form-control"  maxlength="70" placeholder="App Slogan" value="<?php echo e($config->app_slogan); ?>" required>
                                                <?php if($errors->has('app_slogan')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('app_slogan')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <br>
                                            <h4><b><i class="fa fa-fw fa-arrow-right"></i> Captcha Login</b></h4>
                                            <hr/>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="form-group <?php echo e($errors->has('captcha') ? 'has-error' : ''); ?>">
                                                <label for="nome">Captcha Login</label>
                                                <select class="form-control" name="captcha">
                                                    <?php if($config->captcha == 'T'): ?>
                                                    <option value="<?php echo e($config->captcha); ?>">Enable</option>
                                                    <option value="F">Disable</option>
                                                    <?php endif; ?>
                                                    <?php if($config->captcha == 'F'): ?>
                                                    <option value="<?php echo e($config->captcha); ?>">Disable</option>
                                                    <option value="T">Enable</option>
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($errors->has('captcha')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('captcha')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="form-group <?php echo e($errors->has('datasitekey') ? 'has-error' : ''); ?>">
                                                <label for="nome">Site Key</label>
                                                <input type="text" name="datasitekey" class="form-control" placeholder="Site Key"  maxlength="40" value="<?php echo e($config->datasitekey); ?>">
                                                <?php if($errors->has('datasitekey')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('datasitekey')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="form-group <?php echo e($errors->has('recaptcha_secret') ? 'has-error' : ''); ?>">
                                                <label for="nome">Key Secret</label>
                                                <input type="text" name="recaptcha_secret" class="form-control"  maxlength="40" placeholder="Key Secret" value="<?php echo e($config->recaptcha_secret); ?>">
                                                <?php if($errors->has('recaptcha_secret')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('recaptcha_secret')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>  
                                        <div class="col-lg-12">
                                            <br>
                                            <h4><b><i class="fa fa-fw fa-arrow-right"></i> Login Options</b></h4>
                                            <hr/>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="form-group <?php echo e($errors->has('img_login') ? 'has-error' : ''); ?>">
                                                <label for="nome">Image Login</label>
                                                <select class="form-control" name="img_login">
                                                    <?php if($config->img_login == 'T'): ?>
                                                    <option value="<?php echo e($config->img_login); ?>">Enable</option>
                                                    <option value="F">Disable</option>
                                                    <?php endif; ?>
                                                    <?php if($config->img_login == 'F'): ?>
                                                    <option value="<?php echo e($config->img_login); ?>">Disable</option>
                                                    <option value="T">Enable</option>
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($errors->has('img_login')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('img_login')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group <?php echo e($errors->has('titulo_login') ? 'has-error' : ''); ?>">
                                                <label for="nome">Title Login</label>
                                                <input type="text" name="titulo_login" class="form-control"  maxlength="40" placeholder="Title Login" value="<?php echo e($config->titulo_login); ?>" required>
                                                <?php if($errors->has('titulo_login')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('titulo_login')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>                            
                                        <div class="col-lg-2">
                                            <div class="form-group <?php echo e($errors->has('tamanho_img_login') ? 'has-error' : ''); ?>">
                                                <label for="nome">Image size Login</label>
                                                <input type="number" name="tamanho_img_login" class="form-control" value="<?php echo e($config->tamanho_img_login); ?>" required>
                                                <?php if($errors->has('tamanho_img_login')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('tamanho_img_login')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-1">
                                            <label>Current Login Image</label>
                                            <br>
                                            <img src="<?php echo e(asset($config->caminho_img_login)); ?>" width="30px" class="img-thumbnail">
                                            <br><br>
                                        </div>                            
                                        <div class="col-lg-3">
                                            <div class="form-group <?php echo e($errors->has('caminho_img_login') ? 'has-error' : ''); ?>">
                                                <label>Image Login</label>
                                                <input type="file" class="form-control-file"  name="caminho_img_login">
                                                <?php if($errors->has('caminho_img_login')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('caminho_img_login')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <br>
                                            <h4><b><i class="fa fa-fw fa-arrow-right"></i> Layout options</b></h4>
                                            <hr/>
                                        </div> 
                                        <div class="col-lg-4">
                                            <div class="form-group <?php echo e($errors->has('layout') ? 'has-error' : ''); ?>">
                                                <label for="nome">Layout</label>
                                                <select class="form-control" name="layout">
                                                    <option value="<?php echo e($config->layout); ?>"><?php echo e($config->layout); ?></option>
                                                    <option value="layout-boxed">layout-boxed</option>                                        
                                                    <option value="sidebar-collapse">sidebar-collapse</option>                                        
                                                    <option value="fixed">fixed</option>                                        
                                                </select>
                                                <?php if($errors->has('layout')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('layout')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>                            
                                        <div class="col-lg-4">
                                            <div class="form-group <?php echo e($errors->has('skin') ? 'has-error' : ''); ?>">
                                                <label>Skin</label>
                                                <select class="form-control" name="skin">
                                                    <option value="<?php echo e($config->skin); ?>"><?php echo e($config->skin); ?></option>
                                                    <option value="black">Black</option>                                        
                                                    <option value="purple">Purple</option>                                        
                                                    <option value="green">Green</option>                                        
                                                    <option value="red">Red</option>                                        
                                                    <option value="yellow">Yellow</option>                                        
                                                    <option value="blue">Blue</option>                                        
                                                </select>
                                                <?php if($errors->has('skin')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('skin')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>                            
                                        <div class="col-lg-1">
                                            <label>Current Favicon</label>
                                            <br>
                                            <img src="<?php echo e(asset($config->favicon)); ?>" width="30px" class="img-thumbnail">
                                            <br><br>
                                        </div> 
                                        <div class="col-lg-3">
                                            <div class="form-group <?php echo e($errors->has('favicon') ? 'has-error' : ''); ?>">
                                                <label>Favicon</label>
                                                <input type="file"  class="form-control-file" name="favicon">
                                                <?php if($errors->has('favicon')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('favicon')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>  

                                        <div class="col-lg-12">
                                            <br/>
                                            <h4><b><i class="fa fa-fw fa-arrow-right"></i> Register</b></h4>
                                            <hr/>
                                        </div> 

                                        <div class="col-lg-4">
                                            <div class="form-group <?php echo e($errors->has('register') ? 'has-error' : ''); ?>">
                                                <label for="nome">Allows new users via the register screen</label>
                                                <select class="form-control" name="register">
                                                    <?php if($config->register == 'T'): ?>
                                                    <option value="<?php echo e($config->register); ?>">Enable</option>
                                                    <option value="F">Disable</option>
                                                    <?php endif; ?>
                                                    <?php if($config->register == 'F'): ?>
                                                    <option value="<?php echo e($config->register); ?>">Disable</option>
                                                    <option value="T">Enable</option>
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($errors->has('register')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('register')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label for="sistema">Default permission for new users when registering</label>
                                                <select class="form-control" name="default_role_id" required="">
                                                    <option value="">Selecione</option>                                                    
                                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                                        <?php if($role->id != 1): ?>
                                                            <option value="<?php echo e($role->id); ?>" <?php if($config->default_role_id == $role->id): ?> selected <?php endif; ?> ><?php echo e($role->name); ?></option>
                                                        <?php endif; ?>   
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-12"><hr/></div>

                                        <div class="col-lg-12">
                                            <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-fw fa-save"></i> Save</button>
                                        </div>              

                                    </div>                        
                                </form>
                            </div>
                        </div> 

                    </div>

                    <div class="tab-pane" id="permissiongroups">
                        
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-success pull-right" data-toggle="modal" data-target="#modal-add-permission-group"><i class="fa fa-fw fa-plus"></i> Add Permission Group</button>
                                <div class="modal fade" id="modal-add-permission-group">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                                <h4 class="modal-title"><i class="fa fa-plus"></i> Add Permission Group</h4>
                                            </div>
                                            
                                            <form action="<?php echo e(route('config.store.permission_group')); ?>" method="post" enctype="multipart/form-data">
                                                <?php echo e(csrf_field()); ?>


                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="form-group">
                                                                <label>Name</label>
                                                                <input type="text" name="name" class="form-control"  maxlength="50" placeholder="Name" required>
                                                            </div>
                                                        </div>   
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                                                </div>

                                            </form>  
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <br/><br/>
                            <div class="col-md-12">	
                                <div class="table-responsive">
                                    <table class="table table-condensed table-bordered table-hover">
                                        <thead>
                                            <tr>			 
                                                <th>ID</th>			 
                                                <th>Name</th>			 
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>           
                                                    <td><?php echo e($permission_group->id); ?></td>                        
                                                    <td><?php echo e($permission_group->name); ?></td>                        
                                                    <td class="text-center"> 
                                                        <a class="btn btn-warning  btn-xs" href="" title="Edit <?php echo e($permission_group->name); ?>" data-toggle="modal" data-target="#modal-edit-<?php echo e($permission_group->id); ?>"><i class="fa fa-pencil"></i></a> 
                                                    </td> 
                                                </tr>
                                                <div class="modal fade" id="modal-edit-<?php echo e($permission_group->id); ?>">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">×</span>
                                                                </button>
                                                                <h4 class="modal-title"><i class="fa fa-pencil"></i> Edit Permission Group</h4>
                                                            </div>
                                                            
                                                            <form action="<?php echo e(route('config.update.permission_group', $permission_group->id )); ?>" method="post" enctype="multipart/form-data">
                                                                <?php echo e(csrf_field()); ?>

                                                                <input type="hidden" name="_method" value="put">
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-lg-12">
                                                                            <div class="form-group">
                                                                                <label>Name</label>
                                                                                <input type="text" name="name" class="form-control"  maxlength="50" placeholder="Name" value="<?php echo e($permission_group->name); ?>" required>
                                                                            </div>
                                                                        </div>   
                                                                    </div>
                                                                </div>

                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                                                                </div>

                                                            </form>  
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>			 
                                                <th>ID</th>			 
                                                <th>Name</th>			 
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>				
                            <div class="col-md-12 text-center">
                                <?php echo e($permission_groups->links()); ?>

                            </div>
                        </div>

                    </div>

                    <div class="tab-pane" id="permissions">
                        
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-success pull-right" data-toggle="modal" data-target="#modal-add-role"><i class="fa fa-fw fa-plus"></i> Add Permission</button>
                                <div class="modal fade" id="modal-add-role">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                                <h4 class="modal-title"><i class="fa fa-plus"></i> Add Permission</h4>
                                            </div>
                                            
                                            <form action="<?php echo e(route('config.store.permission')); ?>" method="post" enctype="multipart/form-data">
                                                <?php echo e(csrf_field()); ?>


                                                <div class="modal-body">
                                                    <div class="row">                      
                                                        <div class="col-lg-12">
                                                            <div class="form-group">
                                                                <label for="sistema">Permission Group</label>
                                                                <select class="form-control" name="permission_group_id" required="">
                                                                    <option value="">Selecione</option>
                                                                    <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                                                        <option value="<?php echo e($permission_group->id); ?>"> <?php echo e($permission_group->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-12">
                                                            <div class="form-group">
                                                                <label>Name</label>
                                                                <input type="text" name="name" class="form-control"  maxlength="50" placeholder="Name" required>
                                                            </div>
                                                        </div>   
                                                        <div class="col-lg-12">
                                                            <div class="form-group">
                                                                <label>Label</label>
                                                                <input type="text" name="label" class="form-control"  maxlength="50" placeholder="Label" required>
                                                            </div>
                                                        </div> 
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                                                </div>

                                            </form>  
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <br/><br/>
                            <div class="col-md-12">	
                                <div class="table-responsive">
                                    <table class="table table-condensed table-bordered table-hover">
                                        <thead>
                                            <tr>			 
                                                <th>ID</th>			 
                                                <th>Permission Group</th>			 
                                                <th>Name</th>	 
                                                <th>Label</th>		 
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>           
                                                    <td><?php echo e($permission->id); ?></td>  
                                                    <td><?php echo e($permission->permissionGroup->name); ?></td>                        
                                                    <td><?php echo e($permission->name); ?></td>                         
                                                    <td><?php echo e($permission->label); ?></td>                     
                                                    <td class="text-center"> 
                                                        <a class="btn btn-warning  btn-xs" href="" title="Edit <?php echo e($permission->name); ?>" data-toggle="modal" data-target="#modal-edit-<?php echo e($permission->id); ?>"><i class="fa fa-pencil"></i></a> 
                                                    </td> 
                                                </tr>
                                                <div class="modal fade" id="modal-edit-<?php echo e($permission->id); ?>">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">×</span>
                                                                </button>
                                                                <h4 class="modal-title"><i class="fa fa-pencil"></i> Edit Permission</h4>
                                                            </div>
                                                            
                                                            <form action="<?php echo e(route('config.update.permission', $permission->id )); ?>" method="post" enctype="multipart/form-data">
                                                                <?php echo e(csrf_field()); ?>

                                                                <input type="hidden" name="_method" value="put">
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-lg-12">
                                                                            <div class="form-group">
                                                                                <label for="sistema">Permission Group</label>
                                                                                <select class="form-control" name="permission_group_id" required="">
                                                                                    <option value="">Selecione</option>
                                                                                    <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                                                                        <option value="<?php echo e($permission_group->id); ?>" <?php if($permission->permission_group_id == $permission_group->id): ?> selected <?php endif; ?> ><?php echo e($permission_group->name); ?></option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-lg-12">
                                                                            <div class="form-group">
                                                                                <label>Name</label>
                                                                                <input type="text" name="name" class="form-control"  maxlength="50" placeholder="Name" value="<?php echo e($permission->name); ?>" required>
                                                                            </div>
                                                                        </div>   
                                                                        <div class="col-lg-12">
                                                                            <div class="form-group">
                                                                                <label>Label</label>
                                                                                <input type="text" name="label" class="form-control"  maxlength="50" placeholder="Label" value="<?php echo e($permission->label); ?>" required>
                                                                            </div>
                                                                        </div>  
                                                                    </div>
                                                                </div>

                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                                                                </div>

                                                            </form>  
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>			 
                                                <th>ID</th>		
                                                <th>Permission Group</th>	 
                                                <th>Name</th>		 
                                                <th>Label</th>		 
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>				
                            <div class="col-md-12 text-center">
                                <?php echo e($permissions->links()); ?>

                            </div>
                        </div>
                        
                    </div>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/admin/resources/views/config/index.blade.php ENDPATH**/ ?>